PANEL = 'notifications'
PANEL_DASHBOARD = 'monitoring'
REMOVE_PANEL = True
